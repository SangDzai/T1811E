﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Xemyoutubethoi.Model
{
   public class Video
    {
        public string Id { get; set; }
        public string Title { get; set; }
        public string Img { get; set; }
        public string Descriptiong { get; set; }
        public DateTime PubDate { get; set; }

    }
}
